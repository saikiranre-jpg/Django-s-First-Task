from django.shortcuts import render

def first_task(request):
    return render(request,"task.html")
